

Credit and inspiration
======================

Inspired by and derived from https://hpc-carpentry.github.io/hpc-python/
which is distributed under CC-BY 4.0 (https://creativecommons.org/licenses/by/4.0/).
